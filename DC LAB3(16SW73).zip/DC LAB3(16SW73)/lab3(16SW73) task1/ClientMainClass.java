import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
public class ClientMainClass
{
	public static void main(String args[]) throws RemoteException
	{
		try
		{
			int a= Integer.parseInt(args[0]);
			int b= Integer.parseInt(args[1]);
			Registry reg= LocateRegistry.getRegistry("127.0.0.1",9999);
			RemoteClass op=(RemoteClass)
			reg.lookup("RemoteServer");
			System.out.println("First number:" + a);
			System.out.println("Second number:" + b);
			System.out.println("Add:\t"+op.add(a,b));
			System.out.println("Sub:\t"+op.sub(a,b));
			System.out.println("Mul:\t"+op.mul(a,b));
			System.out.println("Div:\t"+op.div(a,b));
			System.out.println("Mod:\t"+op.mod(a,b));



		}
catch(Exception e)
{
	System.out.println(e);
		
}
	}
}