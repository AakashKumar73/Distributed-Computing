import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
public class RemoteServer extends RemoteClass{
	public RemoteServer () throws Exception
	{

	}
	public static void main(String args[]) throws RemoteException{
		try
		{
			Registry reg=LocateRegistry.createRegistry(9999);
			RemoteClass rc=new RemoteClass();
			reg.rebind("RemoteClass",rc);
			System.out.println("Server is ready");

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}