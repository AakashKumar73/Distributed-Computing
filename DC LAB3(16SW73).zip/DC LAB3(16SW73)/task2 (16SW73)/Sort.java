import java.rmi.*;
import java.rmi.server.*;
interface Sort extends Remote{
	int[] sort (int [] array) throws RemoteException;
}