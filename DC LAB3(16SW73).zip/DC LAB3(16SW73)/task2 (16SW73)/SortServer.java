import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
	public class SortServer extends SortRemote {
		public SortServer() throws RemoteException{}
			public static void main(String[] args){
			try{
				Naming.rebind("SortServer", new SortRemote() );

			}
			catch(RemoteException ex) {ex.printStackTrace();}
			catch(java.net.MalformedURLException ex) {ex.printStackTrace();}
			System.out.println("SortRemote Class Bound in RmiRegistry");

			}
	}