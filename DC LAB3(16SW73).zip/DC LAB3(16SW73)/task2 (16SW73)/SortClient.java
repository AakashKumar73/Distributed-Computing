import java.rmi.*;
public class SortClient {
	public static void main(String [] args){
	int[] array = new int[15];
	java.util.Random rn=new java.util.Random();
	for (int i=0; i< array.length; i++)
	array[i]= rn.nextInt(20) + 1;
	for(int i=0; i<array.length; i++)
	System.out.print(array[i] + "  ");
	System.out.println( );
	try {
	Sort sorter =(Sort) Naming.lookup("SortServer");
		array= sorter.sort(array);
	}
	catch(NotBoundException ex) 
	 {ex.printStackTrace();}
	catch(java.net.MalformedURLException ex) {ex.printStackTrace();}
	catch(RemoteException ex) {ex.printStackTrace();}
	for (int i=0; i<array.length; i++)
	System.out.print(array[i] + "  ");
	System.out.println( );
	}
}