import javax.rmi.PortableRemoteObject;
import java.rmi.RemoteException;
public class HelloInterface extends PortableRemoteObject implements InterfaceClass{
	public HelloInterface() throws RemoteException{
		super();
	}
	public String sendSentence(String from) throws RemoteException{
		return "Hello Aakash(16SW73) What are you doing?" + from ;
	}
}