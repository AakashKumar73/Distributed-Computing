import java.rmi.Remote;
public interface InterfaceClass extends Remote{
	public String sendSentence(String from) throws java.rmi.RemoteException;
}