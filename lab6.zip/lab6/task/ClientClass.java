import java.net.MalformedURLException;
import javax.rmi.*;
import java.rmi.*;
import java.util.Vector;
import javax.naming.*;
import java.io.*;

class ClientClass{
	public static String reverseTheSentence(String inputString)
	{
		String[] words = inputString.split("\\s");
		String outputString = "";
		for (int i =words.length-1; i>=0; i--)
		{
			outputString = outputString + words[i] + " ";
		}
		return outputString;
	}

	public static void main(String args[]){
		Context ic;
		Object objref;
		HelloInterface hi;
		try{
			ic=new InitialContext();
			objref=ic.lookup("HelloService");
			System.out.println("Hello Aakash16SW73");
			hi=(HelloInterface) PortableRemoteObject.narrow(objref,HelloInterface.class);
				String inputString = hi.sendSentence(" \n ");
				String outputString = reverseTheSentence(inputString);
				System.out.println("Input String : "+inputString);
				System.out.println("Output String : "+outputString);
			}

			catch(Exception e){
				System.err.println("Exception " + e + "Caught");
				e.printStackTrace();

		return;
		 					}
	}

}