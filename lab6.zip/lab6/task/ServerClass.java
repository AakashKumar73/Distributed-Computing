import javax.naming.InitialContext;
import javax.naming.Context;
public class ServerClass {
	public static void main (String [] args){
		try{
			HelloInterface hi=new HelloInterface();
			Context initialNamingContext = new InitialContext();
				initialNamingContext.rebind("HelloService",hi);
				System.out.println("ServerClass: Ready");

		}
		catch(Exception e){
			System.out.println("Trouble: " + e);
			e.printStackTrace();
		}
	}
}