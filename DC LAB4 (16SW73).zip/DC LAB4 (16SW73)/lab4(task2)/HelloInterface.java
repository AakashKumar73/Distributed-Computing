import java.rmi.*;
public interface HelloInterface extends Remote {
	public String setmsg(ClientInterface ca, String s) throws RemoteException;
}