import java.rmi.*;
import java.io.Serializable;
import java.rmi.server.*;
import java.io.*;

public class HelloClient implements ClientInterface,Serializable
{
	public static void main (String [] args){
		try{
			String s2;
			do{
				HelloInterface obj=(HelloInterface) Naming.lookup("/HelloServer");
				BufferedReader br=new BufferedReader (new InputStreamReader(System.in) );
				System.out.print("Client:");
				s2=br.readLine();
				String s=obj.setmsg((ClientInterface)new HelloClient(),s2);
				System.out.println("Server:"+s);
				if(s2.equals("bye"))
				{System.out.println("End chat");}
			}
			while( (s2.equals("bye")));
		}
		catch(Exception e){
			System.out.println(e);
		}

	}
	public void getmsg(String msg) throws RemoteException
	{
		System.out.println("Client: "+msg);
	}
}