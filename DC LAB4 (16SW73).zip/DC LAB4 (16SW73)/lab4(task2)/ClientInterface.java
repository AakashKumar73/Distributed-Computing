
import java.rmi.*;
public interface ClientInterface extends Remote{
	public void getmsg(String msg) throws RemoteException;
}