import java.rmi.*;
public class RegisterIt
{
	public static void main(String [] args)
	{
		try{
			HelloServer obj=new HelloServer();
			System.out.println("Object instantiated:" + obj);
			Naming.rebind("/HelloServer",obj);
			System.out.println("Server is ready to chat ");
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
}