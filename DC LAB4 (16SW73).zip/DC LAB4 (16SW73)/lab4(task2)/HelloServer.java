import java.rmi.*;
import java.rmi.server.*;
import java.io.*;
import java.rmi.RemoteException;
public class HelloServer extends UnicastRemoteObject implements HelloInterface
{
	public HelloServer () throws RemoteException
	{
		super();
	}
	public String setmsg(ClientInterface ci, String s) throws RemoteException
	{
		String s1 = new String();
		ci.getmsg(s);
		try{
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.print("Server Side: ");
			s1=br.readLine();

		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return s1;
	}
}