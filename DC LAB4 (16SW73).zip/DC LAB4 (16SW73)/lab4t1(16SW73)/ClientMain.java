import java.rmi.Naming;


public class ClientMain{

	public static void main(String[] args){
		try{
			Naming.rebind("rmi://localhost/ClientMain",new RemoteClient() );
		}
		catch(Exception e){
			e.printStackTrace();
		}
		Payroll payroll;
		try{
			payroll = (Payroll)Naming.lookup("serverobj");
			
			System.out.println(payroll.earnings(40,10.5) );
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

} 
	

	