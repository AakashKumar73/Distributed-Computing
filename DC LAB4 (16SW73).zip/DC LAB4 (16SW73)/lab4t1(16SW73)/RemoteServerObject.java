import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.Naming;

public class RemoteServerObject extends UnicastRemoteObject implements Payroll{
	public RemoteServerObject() throws RemoteException {
		super();
	}
	public double earnings (int id , double hrs) throws RemoteException{
		PayrollMsg pmsg;
		String name= "rmi://localhost/Client";
		try{
			pmsg=(PayrollMsg)Naming.lookup(name);
			pmsg.msg();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return id+hrs;
	}
}