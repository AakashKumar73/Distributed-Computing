import java.rmi.Naming;
import java.rmi.server.RemoteServer;


class Server{
	public static void main(String arg[]){
		try{
			String name="rmi://localhost/serverobj";
			Naming.rebind(name, new RemoteServerObject() );
			System.out.println("Ready to recieve request ");

		}
		catch(Exception e){
			e.printStackTrace();
			
		}


	}


}