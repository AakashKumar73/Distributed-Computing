
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

class RemoteClient  extends UnicastRemoteObject implements PayrollMsg{


	public RemoteClient() throws RemoteException{
		System.out.println("Remote Client Constr");
		
	}

	public void msg() throws RemoteException{
		System.out.println("Client Remote Class");
	}


}